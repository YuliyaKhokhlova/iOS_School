//
//  ViewController.m
//  CoreAnimationDemo
//
//  Created by Leonty Deriglazov on 20.12.11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation ViewController {
	CALayer *imageLayer;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	imageLayer = [[CALayer alloc] init];
	imageLayer.contents = (id)[UIImage imageNamed:@"image.jpg"].CGImage;
	imageLayer.frame = CGRectMake(0, 0, 240, 135);
	imageLayer.position = self.view.center;
	[self.view.layer addSublayer:imageLayer];
	
	imageLayer.borderWidth = 5;
	imageLayer.borderColor = [UIColor whiteColor].CGColor;
	imageLayer.shadowOpacity = 1.0;

	// Set up perspective
	CATransform3D transform = self.view.layer.sublayerTransform;
	transform.m34 = 1.0 / -500.0;
	self.view.layer.sublayerTransform = transform;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)animate:(id)sender {
//	CABasicAnimation *rotation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.y"];
//	rotation.toValue = [NSNumber numberWithDouble:M_PI];
//	[imageLayer addAnimation:rotation forKey:nil];
	
	CABasicAnimation *rotation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.y"];
	rotation.toValue = [NSNumber numberWithDouble:M_PI];
	rotation.duration = 0.5;

	imageLayer.zPosition = 100;
	CABasicAnimation *come = [CABasicAnimation animationWithKeyPath:@"zPosition"];
	come.toValue = [NSNumber numberWithDouble:100];


	CGFloat oldY = imageLayer.position.y;
	CAKeyframeAnimation *jump = [CAKeyframeAnimation animationWithKeyPath:@"position.y"];
	jump.values = [NSArray arrayWithObjects:[NSNumber numberWithDouble:oldY],
											[NSNumber numberWithDouble:140],
											[NSNumber numberWithDouble:oldY], nil];

	CAAnimationGroup *animations = [[CAAnimationGroup alloc] init];
	animations.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
	animations.duration = 1;
	animations.animations = [NSArray arrayWithObjects:rotation, come, jump, nil];
	[imageLayer addAnimation:animations forKey:nil];

    //	imageLayer.transform = CATransform3DRotate(imageLayer.transform, M_PI/6, 0, 1, 0);
}

@end
