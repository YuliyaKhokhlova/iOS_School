//
//  ViewController.h
//  CoreAnimationDemo
//
//  Created by Leonty Deriglazov on 20.12.11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)animate:(id)sender;

@end
